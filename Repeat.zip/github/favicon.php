<?DOCTYPE>
<html>
<head>
<meta charset="utf-8">
<link href-"images/favicon.ico" rel="shortcut icon">
<title>Favicon</title>
</head>
<body
</body>
</html>