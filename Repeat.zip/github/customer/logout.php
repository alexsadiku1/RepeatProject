<?php
session_start();

session_destroy();


echo"<script>window.open('..index.php','_self')</script>";


?>
<!--X00101462 Alexandro Sadiku 1stop Repeat Project-->